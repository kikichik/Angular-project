import {Component, ElementRef, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {FormArray, FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {Task} from './task.model';
import {TaskService} from './task.service';
import {Subscription} from 'rxjs';
import {FormService} from './form/form.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy {
  isSomeTaskDone: boolean;
  todoItems: Task[];
  taskSubscription: Subscription;
  statusSubscription: Subscription;
  isShowClicked = true;

  tasks: FormGroup;


  add = this.fb.control('', Validators.min(2));



  ngOnInit(): void {


    this.taskSubscription = this.taskService.tasksChanged
      .subscribe(
        (tasks: Task[]) => {
          this.todoItems = tasks;
        }
      );
    this.statusSubscription = this.taskService.statusesDone
      .subscribe(
        (tasksStatus) => {
          this.isSomeTaskDone = tasksStatus;
        }
      );


    // with BehaviorSubject I can get rid of this
    // this.todoItems = this.taskService.getTasks();
  }
  constructor(private taskService: TaskService,
              private fb: FormBuilder,
              private formService: FormService) {
  }


  ngOnDestroy(): void {
    this.taskSubscription.unsubscribe();
    this.statusSubscription.unsubscribe();
  }

  onAddClick(el: FormControl) {
    this.formService.addTask(el);
    console.log(el);
  }



  onShowClick() {
    this.isShowClicked = !this.isShowClicked;
    console.log(this.todoItems);
  }

  onSaveClick() {
    console.log(this.tasks);
  }

  onSubmit() {
    console.log(this.tasks);
  }


}
