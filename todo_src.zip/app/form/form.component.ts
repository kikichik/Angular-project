import { Component, OnInit } from '@angular/core';
import {FormArray, FormBuilder, FormGroup} from '@angular/forms';
import {TaskService} from '../task.service';
import {FormService} from './form.service';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
  tasks: FormGroup;

  constructor(private fb: FormBuilder,
              private taskService: TaskService,
              private formService: FormService) { }

  ngOnInit() {
  this.tasks = this.formService.createTasks();
  }

  changeTaskStatus(id: number) {
    this.taskService.changeStatus(id);
  }

  onTaskClicked(id: number) {
    setTimeout( () => {
      this.changeTaskStatus(id);
    }, 2000);
  }

  onSubmit() {
    console.log(this.tasks);
  }

}
