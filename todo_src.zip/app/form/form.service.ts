import {FormArray, FormBuilder, FormControl, FormGroup} from '@angular/forms';
import {Injectable} from '@angular/core';
import {TaskService} from '../task.service';

@Injectable()
export class FormService {
  tasks: FormGroup;
  constructor(private fb: FormBuilder,
              private taskService: TaskService) {
  }
  createTasks(): FormGroup {
    this.tasks = this.fb.group({
      list: this.fb.array([])
    });
    for (const task of this.taskService.getTasks()) {
      (<FormArray>this.tasks.get('list')).push(this.fb.group({
        currentTask: [task.task],
        isDone: [task.isDone]
      }));
    }
    console.log(this.tasks);
    return this.tasks;
  }

  addTask(el: FormControl) {
    (<FormArray>this.tasks.get('list')).push(this.fb.group({
      currentTask: el,
      isDone: [false]
    }));
  }
}
