import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormBuilder, FormsModule, ReactiveFormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { RadioDirective } from './radio.directive';
import { TasksComponent } from './tasks/tasks.component';
import { FormComponent } from './form/form.component';
import {FormService} from './form/form.service';
import {TaskService} from './task.service';
@NgModule({
  declarations: [
    AppComponent,
    RadioDirective,
    TasksComponent,
    FormComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    ReactiveFormsModule
  ],
  providers: [FormService, TaskService,  FormBuilder],
  bootstrap: [AppComponent]
})
export class AppModule { }
