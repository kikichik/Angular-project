import { Injectable } from '@angular/core';
import {Task} from './task.model';
import {BehaviorSubject, Observable, Observer, of, Subject} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TaskService {



  private todoItems: Task[] = [
    new Task ('feed a cat'),
    new Task ('do a homework'),
    new Task ('go to the gym')
  ];



  // setting the start value
  tasksChanged = new BehaviorSubject<Task[]>(this.getTasks());
  statusesDone = new BehaviorSubject<boolean>(false);

  getTasks() {
    return this.todoItems.slice();
  }

  addItems(task: string) {
    const newTask = new Task(task);
    this.todoItems.push(newTask);
    this.tasksChanged.next(this.todoItems.slice());
  }

  changeStatus(id: number) {
  this.todoItems[id].isDone = !this.todoItems[id].isDone;
  this.checkAll();
  this.tasksChanged.next(this.todoItems.slice());
  }

  checkAll() {
    for (const item of this.todoItems) {
      if (item.isDone) {
        this.statusesDone.next(true);
        break;
      } else {
        this.statusesDone.next(false);
      }
    }
  }

  constructor() { }
}
