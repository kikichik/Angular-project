export class Task {
  constructor(
    public task: string,
    public isDone = false
  )
  {}
}
