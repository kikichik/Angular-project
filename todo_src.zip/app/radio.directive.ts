import {Directive, ElementRef, HostListener} from '@angular/core';

@Directive({
  selector: '[appRadio]'
})
export class RadioDirective {

  constructor(private el: ElementRef) { }
  @HostListener('click') onRadioClick() {

    if (this.el.nativeElement.checked === 'true') {
      this.el.nativeElement.value = 'off';
    }
    if (this.el.nativeElement.checked === 'false') {
      this.el.nativeElement.checked = 'true';
    }
    console.log(this.el);
  }
}

